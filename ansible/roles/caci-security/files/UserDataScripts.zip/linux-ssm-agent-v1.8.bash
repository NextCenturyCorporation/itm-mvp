#!/bin/bash

#'us-east-1 or 'us-gov-west-1' are the supported regions #
EC2_AVAIL_ZONE=`curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone`
AWSREGION="`echo \"$EC2_AVAIL_ZONE\" | sed 's/[a-z]$//'`"
echo $AWSREGION

###### END OF USER CONFIG #####################################################
# SET GLOBALS FOR REGION
if [[ $AWSREGION == *"gov"* ]]; then
        s3='https://s3-us-gov-west-1.amazonaws.com/amazon-ssm-us-gov-west-1'
elif [ $AWSREGION == us-east-1 ]; then
        s3='https://s3.amazonaws.com/ec2-downloads-windows/SSMAgent'
fi


# Do we have Amzn 1 or 2?
if [ -f /etc/yum.repos.d/amzn-main.repo ]; then
        AWSLINUX1=Y
        yum install -y unzip

elif [ -f /etc/yum.repos.d/amzn2-core.repo ]; then
        AWSLINUX2=Y
        yum install -y unzip 

elif [ -f /etc/yum.repos.d/CentOS-Base.repo ]; then
        sed "s/^#baseurl/baseurl/g;s/^mirrorlist/#mirrorlist/g;" /etc/yum.repos.d/CentOS-Base.repo -i.bak
        CENTOS=Y
		yum install unzip -y
		version_num=$(grep -oP '\d\S\d' /etc/centos-release);
		version_num=${version_num%.*}
elif [ -f /etc/yum.repos.d/redhat-rhui.repo ] || [ -f /etc/yum.repos.d/redhat.repo ]; then
        REDHAT=Y
        #yum-config-manager --enable rhui-REGION-rhel-server-optional
		yum install unzip -y
		version_num=$(grep -oP '\d\S\d' /etc/redhat-release);
		version_num=${version_num%.*}
elif [ -f /etc/update-manager/release-upgrades ]; then
        UBUNTU=Y
        DISTRO=deb
        apt-get install unzip -y
elif grep -q 'NAME="SLES"' /etc/os-release; then
		SLES=Y		

fi

###install
# SSM Agent
echo $version_num
if [ "$REDHAT" = "Y" ]; then
		sudo yum install -y $s3/latest/linux_amd64/amazon-ssm-agent.rpm
		if [ "$version_num" == 6 ]; then
                sudo start amazon-ssm-agent		
        elif [ "$version_num" -ge 7 ]; then
		        sudo systemctl enable amazon-ssm-agent
				sudo systemctl start amazon-ssm-agent
        fi
elif [ "$CENTOS" = "Y" ]; then
		sudo yum install -y $s3/latest/linux_amd64/amazon-ssm-agent.rpm
		if [ "$version_num" == 6 ]; then
                sudo start amazon-ssm-agent
        elif [ "$version_num" -ge 7 ]; then
                sudo systemctl enable amazon-ssm-agent
				sudo systemctl start amazon-ssm-agent
		fi		
elif [ "$SLES" = "Y" ]; then
		mkdir /tmp/ssm
		cd /tmp/ssm
		wget $s3/latest/linux_amd64/amazon-ssm-agent.rpm
		sudo rpm --install amazon-ssm-agent.rpm
		sudo systemctl enable amazon-ssm-agent
		sudo systemctl start amazon-ssm-agent

fi