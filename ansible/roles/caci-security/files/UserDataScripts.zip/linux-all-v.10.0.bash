#!/bin/bash

#'us-east-1 or 'us-gov-west-1' are the supported regions #
EC2_AVAIL_ZONE=`curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone`
AWSREGION="`echo \"$EC2_AVAIL_ZONE\" | sed 's/[a-z]$//'`"
echo $AWSREGION

###### END OF USER CONFIG #####################################################
# SET GLOBALS FOR REGION
if [[ $AWSREGION == *"gov"* ]]; then
        SPLUNK_DEPLOY='10.205.17.10:8089'
        CISBUCKET='cisgov-ec2-software'
        CISPREFIX='EC2-Software'
        S3='https://s3-us-gov-west-1.amazonaws.com'
elif [ $AWSREGION == us-east-1 ]; then
        SPLUNK_DEPLOY='10.205.16.10:8089'
        CISBUCKET='cis-ec2-software'
        CISPREFIX='EC2-Software'
        S3='https://s3.amazonaws.com'
fi

# GLOBAL FILE VARIABLES
if [ -f /etc/yum.repos.d/amzn-main.repo ]; then
        NESSUS_RPM='NessusAgent-amzn.x86_64.rpm'
        SPLUNK_RPM='splunkforwarder-8.0.6-152fb4b2bb96-linux-2.6-x86_64.rpm'
        FalconSensor='falcon-sensor.amzn1.x86_64.rpm'

elif [ -f /etc/yum.repos.d/amzn2-core.repo ]; then
        NESSUS_RPM='NessusAgent-amzn.x86_64.rpm'
        SPLUNK_RPM='splunkforwarder-8.0.6-152fb4b2bb96-linux-2.6-x86_64.rpm'
        FalconSensor='falcon-sensor.amzn2.x86_64.rpm'

elif [ -f /etc/update-manager/release-upgrades ]; then
        export NESSUS_RPM='NessusAgent_amd64.deb'
        export SPLUNK_RPM='splunkforwarder-8.0.6-152fb4b2bb96-linux-2.6-amd64.deb'
        export FalconSensor='falcon-sensor_amd64.deb'

elif [ -f /etc/yum.repos.d/CentOS-Base.repo ]; then
        SPLUNK_RPM='splunkforwarder-8.0.6-152fb4b2bb96-linux-2.6-x86_64.rpm'
        version_num=$(grep -oP '\d\S\d' /etc/centos-release);
        version_num=${version_num%.*}
        echo $version_num
        if [ "$version_num" == 6 ]; then
                NESSUS_RPM='NessusAgent-RC-es6.x86_64.rpm'
        elif [ "$version_num" == 7 ]; then
                NESSUS_RPM='NessusAgent-RC-es7.x86_64.rpm'
                FalconSensor='falcon-sensor.el7.x86_64.rpm'
        elif [ "$version_num" == 8  ]; then
                NESSUS_RPM='NessusAgent-RC-es8.x86_64.rpm'
                FalconSensor='falcon-sensor.el8.x86_64.rpm'
        fi

elif grep -q 'NAME="SLES"' /etc/os-release; then
		SLES=Y
        SPLUNK_RPM='splunkforwarder-8.0.6-152fb4b2bb96-linux-2.6-x86_64.rpm'
        version_num=$(grep -oP 'VERSION="\K\d{1,}' /etc/os-release)
        if [ $version_num == 12 ]; then
                NESSUS_RPM='NessusAgent-suse12.x86_64.rpm'
                FalconSensor='falcon-sensor.suse12.x86_64.rpm'
                SUSE12=Y
        elif [ $version_num == 11 ]; then
                NESSUS_RPM='NessusAgent-suse11.x86_64.rpm'
                SUSE11=Y
        elif [ $version_num == 15 ]; then
                NESSUS_RPM='NessusAgent-suse12.x86_64.rpm'
                FalconSensor='falcon-sensor.suse15.x86_64.rpm'
                SUSE15=Y
        fi	

elif [ -f /etc/yum.repos.d/redhat-rhui.repo ] || [ -f /etc/yum.repos.d/redhat.repo ]; then
        SPLUNK_RPM='splunkforwarder-8.0.6-152fb4b2bb96-linux-2.6-x86_64.rpm'
        version_num=$(grep -oP '\d\S\d' /etc/redhat-release);
        version_num=${version_num%.*}
        echo $version_num
        if [ "$version_num" == 6 ]; then
                NESSUS_RPM='NessusAgent-RC-es6.x86_64.rpm'
        elif [ "$version_num" == 7 ]; then
                NESSUS_RPM='NessusAgent-RC-es7.x86_64.rpm'
                FalconSensor='falcon-sensor.el7.x86_64.rpm'
        elif [ "$version_num" == 8  ]; then
                NESSUS_RPM='NessusAgent-RC-es8.x86_64.rpm'
                FalconSensor='falcon-sensor.el8.x86_64.rpm'
        fi
	
	
fi

#files
echo $NESSUS_RPM
echo $FalconSensor
echo $SPLUNK_RPM

# DIR VARIABLES
NTMP='/tmp/cis/nessus'
STMP='/tmp/cis/splunk'
CTMP='/tmp/cis/crowdstrike'

# Make dirs for software downloads
mkdir -p $NTMP $STMP $CTMP

# function to handle downloading agents from S3
# Necessary since by default instances have to use the S3 endpoint.
function download_files {
	wget "${S3}/${CISBUCKET}/${CISPREFIX}/Nessus-agents/${NESSUS_RPM}" -O "${NTMP}/${NESSUS_RPM}" 2>/dev/null || curl --output "${NTMP}/${NESSUS_RPM}" "${S3}/${CISBUCKET}/${CISPREFIX}/Nessus-agents/${NESSUS_RPM}"
	echo "#########Downloading Files" $NESSUS_RPM
	wget "${S3}/${CISBUCKET}/${CISPREFIX}/Crowdstrike/${FalconSensor}" -O "${CTMP}/${FalconSensor}" 2>/dev/null || curl --output  "${CTMP}/${FalconSensor}" "${S3}/${CISBUCKET}/${CISPREFIX}/Crowdstrike/${FalconSensor}"
	echo "#########Downloading Files" $FalconSensor
	wget "${S3}/${CISBUCKET}/${CISPREFIX}/Splunk/${SPLUNK_RPM}" -O "${STMP}/${SPLUNK_RPM}" 2>/dev/null || curl --output "${STMP}/${SPLUNK_RPM}" "${S3}/${CISBUCKET}/${CISPREFIX}/Splunk/${SPLUNK_RPM}"
	echo "#########Downloading Files" $SPLUNK_RPM
}


# Do we have Amzn 1 or 2?
if [ -f /etc/yum.repos.d/amzn-main.repo ]; then
        AWSLINUX1=Y
        yum install -y unzip

elif [ -f /etc/yum.repos.d/amzn2-core.repo ]; then
        AWSLINUX2=Y
        yum install -y unzip 
        yum install libnl -y

elif [ -f /etc/yum.repos.d/CentOS-Base.repo ]; then
        sed "s/^#baseurl/baseurl/g;s/^mirrorlist/#mirrorlist/g;" /etc/yum.repos.d/CentOS-Base.repo -i.bak
        CENTOS=Y
		yum install unzip -y
        yum install libnl -y

elif [ -f /etc/yum.repos.d/redhat-rhui.repo ] || [ -f /etc/yum.repos.d/redhat.repo ]; then
        REDHAT=Y
        yum-config-manager --enable rhui-REGION-rhel-server-optional
		yum install unzip -y

elif [ -f /etc/update-manager/release-upgrades ]; then
        UBUNTU=Y
        DISTRO=deb
        apt-get install unzip -y

fi


# run function to download files from S3
download_files


# Nessus Agent

if  [ "$UBUNTU" = "Y" ]; then
       if [ -f /opt/nessus_agent/sbin/nessuscli ]; then
            echo "NessusAgent exists"
       else
            lsb_release -a | grep 14.04
            if [ $? == 0 ]; then
                dpkg -i $NTMP/$NESSUS_RPM
       else
            apt-get install -y $NTMP/$NESSUS_RPM
            /etc/init.d/nessusagent start
            /opt/nessus_agent/sbin/nessuscli agent link --key=6ef7ca73bd6a508b4e4b6ead250deb8a1eec2d52f9929f551e9d8d62d8302a14 --groups=AWS-Linux --host=377-nessusmgr-01.caci.com --port=8834
            fi
       fi
else
        if [ -f /opt/nessus_agent/sbin/nessuscli ]; then
            echo "NessusAgent exists"
        else
            rpm -Uvh $NTMP/$NESSUS_RPM
            /sbin/service nessusagent start
            /opt/nessus_agent/sbin/nessuscli agent link --key=6ef7ca73bd6a508b4e4b6ead250deb8a1eec2d52f9929f551e9d8d62d8302a14 --groups=AWS-Linux --host=377-nessusmgr-01.caci.com --port=8834
        fi
fi

# CrowdStrike Agent

if  [ "$UBUNTU" = "Y" ]; then
    if ! pgrep -x "falcon-sensor" >/dev/null; then
        lsb_release -a | grep 14.04
        if [ $? == 0 ]; then
            dpkg -i $CTMP/$FalconSensor
        else
            apt-get install -y $CTMP/$FalconSensor
            /opt/CrowdStrike/falconctl -s --cid=2C44189B41D3490C836C0E2C39492C78-25 --provisioning-token=160ED153 --tags="CoreNET-Servers"
        systemctl start falcon-sensor
        fi
    else
        echo "Crowdstrike running"
    fi
else
    if ! pgrep -x "falcon-sensor" >/dev/null; then
        rpm -Uvh $CTMP/$FalconSensor
        /opt/CrowdStrike/falconctl -s --cid=2C44189B41D3490C836C0E2C39492C78-25 --provisioning-token=160ED153 --tags="CoreNET-Servers"
        service falcon-sensor start
    else
        echo "Crowdstrike is running"
    fi
fi


# Splunk forwarder
#Check Splunk Version
SPV=$(/opt/splunkforwarder/bin/splunk version)
echo $SPV
# see if splunk is already running, if not install our download
if ! pgrep -x "splunkd" >/dev/null; then
    rpm -Uvh $STMP/$SPLUNK_RPM
        dpkg -i $STMP/$SPLUNK_RPM

    # Splunk Configurations
    /opt/splunkforwarder/bin/splunk set deploy-poll ${SPLUNK_DEPLOY} --accept-license --answer-yes --auto-ports --no-prompt
    /opt/splunkforwarder/bin/splunk enable boot-start
    /opt/splunkforwarder/bin/splunk start
elif [[ $SPV != *"8.0.6"* ]]; then
    # Stop Splunk
    /opt/splunkforwarder/bin/splunk stop
    # Install Splunk
    rpm -Uvh $STMP/$SPLUNK_RPM
        dpkg -i $STMP/$SPLUNK_RPM
    # Splunk Config
    /opt/splunkforwarder/bin/splunk set deploy-poll ${SPLUNK_DEPLOY} --accept-license --answer-yes --auto-ports --no-prompt
    /opt/splunkforwarder/bin/splunk enable boot-start --accept-license --answer-yes --auto-ports --no-prompt
    /opt/splunkforwarder/bin/splunk start --accept-license --answer-yes --auto-ports --no-prompt
fi
