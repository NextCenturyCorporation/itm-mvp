<powershell>
### Set Variable ###

$CIS_Directory = "c:\cis";
$Software_Directory = "c:\cis\EC2-Software";

$S3BucketName = ""
$SetRegion = ""
$SplunkServer = ""

$Region = (Invoke-WebRequest -uri "http://169.254.169.254/latest/meta-data/placement/availability-zone").Content
Write-Host $Region
if ($Region -like "*gov*"){
    $S3BucketName = "cisgov-ec2-software"
    $SetRegion = "us-gov-west-1"
    $SplunkServer = "10.205.17.10"
} else{
    $S3BucketName = "cis-ec2-software"
    $SetRegion = "us-east-1"
    $SplunkServer = "10.205.16.10"
}

$S3KeyPrefixDirectory ="EC2-Software";
$SetLocation_Crowdstrike = "c:\cis\EC2-Software\Crowdstrike";
$SetLocation_Splunk ="c:\cis\EC2-Software\Splunk";
$SetLocation_Wsus = "c:\cis\EC2-Software\WSUS";
$SetLocation_WATP = "c:\cis\EC2-Software\WATP";
$SetLocation_Nessus = "C:\cis\EC2-Software\Nessus-agents";

function Invoke-Functions
{
    Copy-File
    Install-Crowdstrike
    Install-SplunkUF
    Install-Nessus
    set-WATP
    set-Registry
    clean-up
}

function Copy-File
{
    mkdir $CIS_Directory
    #set-location $CIS_Directory 

    read-s3object `
        -BucketName $S3BucketName `
        -KeyPrefix $S3KeyPrefixDirectory `
        -Folder $CIS_Directory\$S3KeyPrefixDirectory `
        -Region $SetRegion
}

function Install-Crowdstrike
{
$ProcessName = "CSFalconService"
if((get-process $ProcessName -ErrorAction SilentlyContinue) -eq $Null)
{set-location $SetLocation_Crowdstrike
$ArgList = "/install /quiet /norestart CID=2C44189B41D3490C836C0E2C39492C78-25 ProvToken=160ED153 GROUPING_TAGS=" + "CoreNET-Servers"
start-process "WindowsSensor.GovLaggar.exe" -ArgumentList "$ArgList" -wait}
else {echo "Crowdstrike is running"}
}

function Install-SplunkUF
{
    $ProcessName = "splunkd"
    $splunkversion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo("C:\Program Files\SplunkUniversalForwarder\bin\splunkd.exe").FileVersion
    if((get-process $ProcessName -ErrorAction SilentlyContinue) -eq $Null)
        {set-location $SetLocation_Splunk
        $ArgList = "-i splunkforwarder-8.0.6-152fb4b2bb96-x64-release.msi DEPLOYMENT_SERVER=" + "$SplunkServer" + ":8089 AGREETOLICENSE=yes /quiet /L*v splunk_logfile.txt "
        start-process -filepath "msiexec.exe" -ArgumentList "$ArgList" -Wait} 
	 elseif ($splunkversion -ne "8.0.6")
        {set-location $SetLocation_Splunk
		$ArgList = "-i splunkforwarder-8.0.6-152fb4b2bb96-x64-release.msi DEPLOYMENT_SERVER=" + "$SplunkServer" + ":8089 AGREETOLICENSE=yes /quiet /L*v splunk_logfile.txt "
        start-process -filepath "msiexec.exe" -ArgumentList "$ArgList" -Wait}
     else {echo "Splunk is running"}
}

function Install-Nessus
{
	$ProcessName = "nessus-service"
    if((get-process $ProcessName -ErrorAction SilentlyContinue) -eq $Null)
		{set-location $SetLocation_Nessus
		start-process -filepath "msiexec.exe" -ArgumentList "/i NessusAgent-7.5.1-x64.msi NESSUS_GROUPS=AWS-Windows NESSUS_SERVER=377-nessusmgr-01.caci.com:8834 NESSUS_KEY=6ef7ca73bd6a508b4e4b6ead250deb8a1eec2d52f9929f551e9d8d62d8302a14 /qn" -Wait}	
		else {echo "Nessus is running"}
}

function set-WATP
{
$ProcessName = "CSFalconService"
if((get-process $ProcessName -ErrorAction SilentlyContinue) -ne $Null)
{set-location $SetLocation_WATP
start-process -filepath "regedit.exe" -ArgumentList "/s WATP.reg" -Wait}
else {echo "Crowdstrike is not running"}
}

function set-Registry
{
	set-location $SetLocation_Wsus
    start-process -filepath "regedit.exe" -ArgumentList "/s wsus.reg" -Wait
}

function clean-up
{
   	set-location $CIS_Directory 
	Remove-Item $Software_Directory -Recurse -Force
}


Invoke-Functions

</powershell>

